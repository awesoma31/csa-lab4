package main

import (
	"bytes"
	"encoding/binary"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"github.com/awesoma31/csa-lab4/pkg/translator/codegen"
	"github.com/awesoma31/csa-lab4/pkg/translator/parser"
	"github.com/sanity-io/litter"
)

func main() {
	source := `
        let a = 10;
        let b = "hello_world";
        let c = a + 5;
        if (c > 10) {
            let d = 20;
            c = c + d;
        } else {
            c = c - 5;
        }
        // print(c); // Предполагается, что 'print' - это встроенная функция или внешний вызов
        // let s = "test_string";
        // func my_func(x, y) {
        //   let z = x + y;
        //   return z;
        // }
        // let result = my_func(c, 100);
    `

	program, parseErrors := parser.Parse(source)
	if len(parseErrors) > 0 {
		fmt.Println("Ошибки парсера:")
		for _, err := range parseErrors {
			fmt.Println("-", err)
		}
		os.Exit(1)
	}

	litter.Dump(program)

	// 2. Кодогенерация
	// Создаем новый генератор кода.
	cg := codegen.NewCodeGenerator()
	// Запускаем процесс генерации кода, передавая ему AST.
	// В результате получаем память инструкций, память данных,
	// отладочный ассемблер и список ошибок кодогенерации.
	instructionMemory, dataMemory, debugAssembly, cgErrors := cg.Generate(program)

	if len(cgErrors) > 0 {
		fmt.Println("Ошибки кодогенерации:")
		for _, err := range cgErrors {
			fmt.Println("-", err)
		}
		os.Exit(1) // Завершаем программу при наличии ошибок кодогенерации
	}

	// 3. Вывод результатов в файлы
	outputDir := "output"
	// Создаем директорию 'output', если ее нет. Разрешения 0755 для директорий (read/write/execute for owner, read/execute for group/others)
	os.MkdirAll(outputDir, 0755)

	// Сохраняем отладочный ассемблер в файл .asm
	debugAsmPath := filepath.Join(outputDir, "output.asm")
	err := os.WriteFile(debugAsmPath, []byte(strings.Join(debugAssembly, "\n")), 0644) // Разрешения 0644 для файлов (read/write for owner, read for group/others)
	if err != nil {
		fmt.Println("Ошибка при записи отладочного ассемблера:", err)
	} else {
		fmt.Printf("Отладочный ассемблер сохранен в %s\n", debugAsmPath)
	}

	// Сохраняем бинарные файлы памяти инструкций
	instrBinPath := filepath.Join(outputDir, "instruction_memory.bin")
	err = writeBinaryFile(instrBinPath, instructionMemory)
	if err != nil {
		fmt.Println("Ошибка при записи бинарного файла памяти инструкций:", err)
	} else {
		fmt.Printf("Бинарный файл памяти инструкций сохранен в %s\n", instrBinPath)
	}

	// Сохраняем бинарные файлы памяти данных
	dataBinPath := filepath.Join(outputDir, "data_memory.bin")
	err = writeBinaryFile(dataBinPath, dataMemory)
	if err != nil {
		fmt.Println("Ошибка при записи бинарного файла памяти данных:", err)
	} else {
		fmt.Printf("Бинарный файл памяти данных сохранен в %s\n", dataBinPath)
	}
}

// writeBinaryFile записывает слайс uint32 в бинарный файл.
// Использует LittleEndian для записи, что является распространенным выбором для большинства систем.
func writeBinaryFile(filename string, data []uint32) error {
	file, err := os.Create(filename)
	if err != nil {
		return err
	}
	defer file.Close() // Гарантируем закрытие файла при выходе из функции

	writer := binary.NewWriter(file) // Создаем новый writer для бинарной записи
	for _, word := range data {
		// Записываем каждое 32-битное слово (4 байта)
		err := writer.WriteUint32(word, binary.LittleEndian) // Предположим Little-Endian
		if err != nil {
			return err
		}
	}
	return nil
}

// getPrettyJson форматирует JSON байты в удобочитаемую строку с отступами.
func getPrettyJson(in []byte) (string, error) {
	var prettyJson bytes.Buffer
	err := json.Indent(&prettyJson, []byte(in), "", " ")
	if err != nil {
		return "", err
	}
	return prettyJson.String(), nil
}
